<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="PROOP" tilewidth="16" tileheight="16" tilecount="400" columns="20">
 <image source="all.png" width="320" height="320"/>
</tileset>
